#ifndef FIXCOL_H
#define FIXCOL_H

#include <stdio.h>

void fixcol(long, FILE*);

#endif
